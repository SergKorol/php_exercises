<HTML>
<HEAD>
<TITLE>strlen</TITLE>
</HEAD>
<BODY>
<?
	$text = "a short string";
	print("'$text' is " . strlen($text) . " characters long.");
?>
</BODY>
</HTML>