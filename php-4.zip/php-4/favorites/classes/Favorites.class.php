<?
class Favorites{
  private $plugins = [];
	
  function __construct(){}
	
  private function findPlugins() {}
	
  function getFavorites($methodName) {
    $list = [];
  }
}
