<HTML>
<HEAD>
<TITLE>tan</TITLE>
</HEAD>
<BODY>
<?
	//prints 1.5574077246549
	print(tan(1));
?>
</BODY>
</HTML>