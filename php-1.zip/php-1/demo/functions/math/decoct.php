<HTML>
<HEAD>
<TITLE>decoct</TITLE>
</HEAD>
<BODY>
<?
	//prints 377
	print(decoct(255));
?>
</BODY>
</HTML>