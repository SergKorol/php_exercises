<HTML>
<HEAD>
<TITLE>round</TITLE>
</HEAD>
<BODY>
<?
	//prints 1
	print(round(1.4) . "<BR>\n");

	//prints 1
	print(round(1.5) . "<BR>\n");

	//prints 2
	print(round(1.6) . "<BR>\n");
?>
</BODY>
</HTML>