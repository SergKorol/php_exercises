<HTML>
<HEAD>
<TITLE>trim</TITLE>
</HEAD>
<BODY>
<?
	$text = "     whitespace      ";
	print("\"" . trim($text) . "\"");
?>
</BODY>
</HTML>