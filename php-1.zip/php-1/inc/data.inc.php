<?php
$leftMenu = [
				['link'=>'Домой', 'href'=>'index.php'],
				['link'=>'О нас', 'href'=>'index.php?id=about'], 
				['link'=>'Контакты', 'href'=>'index.php?id=contact'], 
				['link'=>'Таблица умножения', 'href'=>'index.php?id=table'], 
				['link'=>'Калькулятор', 'href'=>'index.php?id=calc']
			];


/*
     * Получаем текущий час в виде строки от 00 до 23
     * и приводим строку к целому числу от 0 до 23
     */

//установка зоны времени, если она глобально отличается
date_default_timezone_set('Europe/Kiev');
$hour = (int)strftime('%H');
$welcome = 'Доброй ночи';// Инициализируем переменную для приветствия
if($hour >= 6 AND $hour < 12) 
    $welcome = "Доброе утро";
elseif($hour >= 12 AND $hour < 18) 
    $welcome = "Добрый день";
elseif($hour >= 18 AND $hour > 23)
    $welcome = "Добрый вечер";

 

?>

<?php
// Объявление константы
define('COPYRIGHT', 'Супер Мега Веб-мастер');
?>

<?php
// Установка локали и выбор значений даты
        setlocale(LC_ALL, "russian");
        $day = strftime('%d');
        $mon = strftime('%B');
        $year = strftime('%Y');
?>