<!-- Навигация -->
<h2>Навигация по сайту</h2>
			<!-- Меню -->
			<?php
			$style = '';
				echo "<ul>";
				foreach ($leftMenu as $item) {
					echo "<li$style>";
					echo "<a href='$item[href]'>{$item['link']}</a>&nbsp;";
					echo "</li>";
				}
				echo "</ul>";
			?>
			
			<!-- Меню -->
<!-- Навигация -->