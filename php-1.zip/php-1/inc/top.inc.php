<!-- Верхняя часть страницы -->
	<img src="logo.gif" width="187" height="29" alt="Наш логотип" class="logo" />
			<span class="slogan">приходите к нам учиться</span>		
<!-- Верхняя часть страницы -->

