<HTML>
<HEAD>
<TITLE>settype</TITLE>
</HEAD>
<BODY>
<?
	$myValue = 123.45;
	settype($myValue, "integer");
	print($myValue);
?>
</BODY>
</HTML>