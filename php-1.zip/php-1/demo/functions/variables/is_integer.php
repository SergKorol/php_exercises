<HTML>
<HEAD>
<TITLE>is_integer</TITLE>
</HEAD>
<BODY>
<?
	$PageCount = 2234;
	if(is_integer($PageCount))
	{
		print("$PageCount is an integer");
	}
?>
</BODY>
</HTML>