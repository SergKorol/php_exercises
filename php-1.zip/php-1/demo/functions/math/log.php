<HTML>
<HEAD>
<TITLE>log</TITLE>
</HEAD>
<BODY>
<?
	//prints 3.0022112396517
	print(log(20.13));
?>
</BODY>
</HTML>