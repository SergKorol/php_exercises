<HTML>
<HEAD>
<TITLE>strval</TITLE>
</HEAD>
<BODY>
<?
	$myNumber = 13;
	print(strval($myNumber));
?>
</BODY>
</HTML>