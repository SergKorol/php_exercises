<HTML>
<HEAD>
<TITLE>echo</TITLE>
</HEAD>
<BODY>
<?
	echo "First string", 2, 3.4, "last string";
?>
</BODY>
</HTML>