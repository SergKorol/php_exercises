<?php
			//Рисуем меню
				drawMenu($leftMenu, false);
?>
			
			<!-- Нижняя часть страницы -->
			&copy; <?php echo COPYRIGHT?>, 2000 - <?= strftime('%Y')?>
			<!-- Нижняя часть страницы -->