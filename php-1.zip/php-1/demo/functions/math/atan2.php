<HTML>
<HEAD>
<TITLE>atan2</TITLE>
</HEAD>
<BODY>
<?
	//print 0.40489178628508
	print(atan2(3, 7));
?>
</BODY>
</HTML>
