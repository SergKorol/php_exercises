<HTML>
<HEAD>
<TITLE>strcmp</TITLE>
</HEAD>
<BODY>
<?
	$first = "abc";
	$second = "xyz";

	if(strcmp($first, $second) == 0)
	{
		print("strings are equal");
	}
	else
	{
		print("strings are not equal");
	}
?>
</BODY>
</HTML>