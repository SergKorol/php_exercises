<HTML>
<HEAD>
<TITLE>base_convert</TITLE>
</HEAD>
<BODY>
<?
	//convert hex CC to decimal
	print(base_convert("CC", 16, 10));
?>
</BODY>
</HTML>