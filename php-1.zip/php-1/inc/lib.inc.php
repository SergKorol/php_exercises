<?php
function drawTable($cols = 10, $rows = 10, $color = "yellow")
{
	echo '<table border="1" width="200">';
					for ($tr = 1; $tr < $rows; $tr++) {
						echo '<tr>';
						for ($td = 1; $td < $cols; $td++){
							if($td == 1 OR $tr == 1)
								echo "<th style='background:yellow'>" .$td*$tr. '</th>';
							else 
								echo '<td>' .$td*$tr. '</td>';	
							
						}
						echo '</tr>';
					}
				echo '</table>';	
}

function drawMenu($menu, $vertical = true)
{
	$style = '';
	if(!$vertical)
		$style = " style=display:inline;margin-right:15px";
	echo "<ul>";
		foreach ($menu as $item) {
				echo "<li$style>";
				echo "<a href='$item[href]'>{$item['link']}</a>";
				echo "</li>";
				}
	echo "</ul>";
	
}

function myError($errno, $errmsg, $errfile, $errline){
    // Логгируем пользовательские ошибки
    switch ($errno) {
      case E_USER_ERROR:
      case E_USER_WARNING:
      case E_USER_NOTICE:
error_log("$errmsg\n", 3, "error.log"); }
}

?>