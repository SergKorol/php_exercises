<HTML>
<HEAD>
<TITLE>md5</TITLE>
</HEAD>
<BODY>
<?
	print(md5("Who is John Galt?"));
?>
</BODY>
</HTML>