<HTML>
<HEAD>
<TITLE>range</TITLE>
</HEAD>
<BODY>
<?
	$numbers = range(13, 19);

	//print out all the values
	foreach($numbers as $value)
	{
		print("$value<BR>\n");
	}
?>
</BODY>
</HTML>