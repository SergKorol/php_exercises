<HTML>
<HEAD>
<TITLE>rad2deg</TITLE>
</HEAD>
<BODY>
<?
	//print 90.00021045915
	print(rad2deg(1.5708));
?>
</BODY>
</HTML>