<HTML>
<HEAD>
<TITLE>exp</TITLE>
</HEAD>
<BODY>
<?
	//prints 20.085536923188
	print(exp(3));
?>
</BODY>
</HTML>