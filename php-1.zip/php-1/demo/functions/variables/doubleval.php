<HTML>
<HEAD>
<TITLE>doubleval</TITLE>
</HEAD>
<BODY>
<?
	$myNumber = "13.1cm";
	print(doubleval($myNumber));
?>
</BODY>
</HTML>