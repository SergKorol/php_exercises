<HTML>
<HEAD>
<TITLE>strtoupper</TITLE>
</HEAD>
<BODY>
<?
	print(strtoupper("Hello World"));
?>
</BODY>
</HTML>