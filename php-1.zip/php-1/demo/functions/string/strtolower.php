<HTML>
<HEAD>
<TITLE>strtolower/TITLE>
</HEAD>
<BODY>
<?
	print(strtolower("Hello World"));
?>
</BODY>
</HTML>