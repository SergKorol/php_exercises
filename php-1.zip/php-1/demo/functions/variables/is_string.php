<HTML>
<HEAD>
<TITLE>is_string</TITLE>
</HEAD>
<BODY>
<?
	$Greeting = "Hello";
	if(is_string($Greeting))
	{
		print("Greeting is a string");
	}
?>
</BODY>
</HTML>