<HTML>
<HEAD>
<TITLE>ceil</TITLE>
</HEAD>
<BODY>
<?
	//print 14
	print(ceil(13.2));
?>
</BODY>
</HTML>