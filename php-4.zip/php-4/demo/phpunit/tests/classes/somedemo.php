<?php
class SomeDemo {

  public function div($a,$b) {
    return $a/$b;
  }

  public function mult($a,$b) {
    return $a*$b;
  }
}