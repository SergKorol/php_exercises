<HTML>
<HEAD>
<TITLE>strftime</TITLE>
</HEAD>
<BODY>
<?
	
	//Monday, 01/01/01 16:04:12
	print(strftime("%A, %c"));
?>
</BODY>
</HTML>